# 인터파크 백엔드 프로젝트

- 인터파크 리액트 스터디
- [결과물 보기](https://)

## 프로젝트 설명

### 적용기술

- Node.js
- Express.js


### 기타사항

- 프로젝트 생성

```js
npm run start
```
